const fs = require("fs");
const path = require("path");

const STORE_PATH = path.join(__dirname, "..", "data", "store.json");
const ORDERS_PATH = path.join(__dirname, "..", "data", "orders.json");

function readJson(filePath) {
  const raw = fs.readFileSync(filePath, "utf-8");
  return JSON.parse(raw);
}

function writeJson(filePath, data) {
  // Escritura atómica simple: escribe a un temp y renombra.
  const tmpPath = filePath + ".tmp";
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), "utf-8");
  fs.renameSync(tmpPath, filePath);
}

module.exports = {
  getStore: () => readJson(STORE_PATH),
  saveStore: (data) => writeJson(STORE_PATH, data),
  getOrders: () => readJson(ORDERS_PATH),
  saveOrders: (data) => writeJson(ORDERS_PATH, data),
};
