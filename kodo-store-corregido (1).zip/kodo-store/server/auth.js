function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) {
    return next();
  }
  return res.status(401).json({ error: "No autorizado. Iniciá sesión como admin." });
}

function login(req, res) {
  const { user, pass } = req.body || {};
  const ADMIN_USER = process.env.ADMIN_USER;
  const ADMIN_PASS = process.env.ADMIN_PASS;

  // No usar credenciales conocidas por defecto: obligar a configurar el acceso.
  if (!ADMIN_USER || !ADMIN_PASS) {
    return res.status(503).json({ error: "El acceso admin no está configurado en el servidor." });
  }

  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    req.session.isAdmin = true;
    req.session.user = user;
    return res.json({ ok: true, user });
  }
  return res.status(401).json({ error: "Usuario o contraseña incorrectos." });
}

function logout(req, res) {
  req.session = null;
  res.json({ ok: true });
}

function me(req, res) {
  if (req.session && req.session.isAdmin) {
    return res.json({ isAdmin: true, user: req.session.user });
  }
  return res.json({ isAdmin: false });
}

module.exports = { requireAdmin, login, logout, me };
