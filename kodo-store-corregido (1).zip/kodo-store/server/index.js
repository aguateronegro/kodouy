require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");
const cookieSession = require("cookie-session");
const multer = require("multer");
const { nanoid } = require("nanoid");

const db = require("./db");
const auth = require("./auth");
const mp = require("./mercadopago");

const app = express();
const PORT = process.env.PORT || 3000;

// La tienda es same-origin; no habilitamos CORS abierto por defecto.
// Si se necesita una API externa, configurar explícitamente los orígenes permitidos.
app.use(express.json());
app.use(
  cookieSession({
    name: "kodo_admin",
    secret: process.env.SESSION_SECRET || "dev-secret-cambiar-por-un-secreto-largo",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 12 * 60 * 60 * 1000, // 12hs
    sameSite: "lax",
  })
);

// --- Archivos estáticos (frontend + imágenes subidas) ---
app.use(express.static(path.join(__dirname, "..", "public")));
app.use("/uploads", express.static(path.join(__dirname, "..", "public", "uploads")));

// --- Subida de imágenes (solo admin) ---
const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, "..", "public", "uploads"),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname) || ".jpg";
      cb(null, `${nanoid(10)}${ext}`);
    },
  }),
  limits: { fileSize: 8 * 1024 * 1024 }, // 8MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Solo se permiten imágenes"));
    }
    cb(null, true);
  },
});

// =====================================================
// RUTAS PÚBLICAS
// =====================================================

// Configuración del sitio + productos (para armar el home/tienda)
app.get("/api/store", (req, res) => {
  const store = db.getStore();
  res.json({ ...store, mpConfigured: mp.isConfigured() });
});

// Crear un pedido + generar el link de pago de Mercado Pago
app.post("/api/orders", async (req, res) => {
  try {
    const { items, customer, shippingZoneId } = req.body || {};

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "El carrito está vacío." });
    }
    if (!customer || !customer.name?.trim() || !customer.phone?.trim() || !customer.address?.trim() || !customer.locality?.trim()) {
      return res.status(400).json({ error: "Faltan datos del comprador." });
    }

    const store = db.getStore();
    const zone = (store.site.shippingZones || []).find((z) => z.id === shippingZoneId);
    if (!zone) {
      return res.status(400).json({ error: "Zona de envío inválida." });
    }

    // Recalculamos precios desde el catálogo real (nunca confiamos en el precio que manda el cliente)
    const catalog = new Map(store.products.map((p) => [p.id, p]));
    const validatedItems = items.map((it) => {
      const product = catalog.get(it.productId);
      if (!product || !product.active) throw new Error(`Producto inexistente o inactivo: ${it.productId}`);
      const qty = Number(it.qty);
      if (!Number.isInteger(qty) || qty < 1 || qty > 99) throw new Error("Cantidad inválida.");
      if (product.colors?.length && !product.colors.includes(it.color)) throw new Error("Color inválido.");
      if (product.sizes?.length && !product.sizes.includes(it.size)) throw new Error("Talle inválido.");
      return {
        productId: product.id,
        name: product.name,
        size: it.size,
        color: it.color,
        qty,
        price: product.price,
      };
    });

    const total = validatedItems.reduce((sum, it) => sum + it.price * it.qty, 0);

    const order = {
      id: nanoid(8).toUpperCase(),
      items: validatedItems,
      customer: {
        name: customer.name,
        phone: customer.phone,
        address: customer.address,
        locality: customer.locality,
        instructions: customer.instructions || "",
      },
      shippingZone: zone.name,
      shippingPrice: zone.price,
      total,
      status: "PEDIDO RECIBIDO",
      paid: false,
      mpPreferenceId: null,
      createdAt: new Date().toISOString(),
    };

    const { initPoint, preferenceId, configured } = await mp.createPreference(order);
    order.mpPreferenceId = preferenceId;

    const orders = db.getOrders();
    orders.push(order);
    db.saveOrders(orders);

    res.json({
      orderId: order.id,
      total: order.total,
      checkoutUrl: initPoint,
      mpConfigured: configured,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo crear el pedido." });
  }
});

// Seguimiento de pedido (público, solo con el número de pedido)
app.get("/api/orders/:id", (req, res) => {
  const orders = db.getOrders();
  const order = orders.find((o) => o.id === req.params.id.toUpperCase());
  if (!order) return res.status(404).json({ error: "Pedido no encontrado." });

  res.json({
    id: order.id,
    status: order.status,
    paid: order.paid,
    createdAt: order.createdAt,
    total: order.total,
    itemsCount: order.items.reduce((n, it) => n + it.qty, 0),
  });
});

// Webhook de Mercado Pago: confirma pagos automáticamente
app.post("/api/mp/webhook", async (req, res) => {
  try {
    const paymentId = req.query["data.id"] || req.body?.data?.id;
    const topic = req.query.type || req.body?.type;

    if (topic === "payment" && paymentId) {
      const payment = await mp.getPayment(paymentId);
      const externalRef = payment?.external_reference;
      const status = payment?.status; // approved, pending, rejected...

      if (externalRef && status === "approved") {
        const orders = db.getOrders();
        const order = orders.find((o) => o.id === externalRef);
        if (order && !order.paid) {
          order.paid = true;
          if (order.status === "PEDIDO RECIBIDO") order.status = "PREPARANDO";
          db.saveOrders(orders);
        }
      }
    }
    res.sendStatus(200);
  } catch (err) {
    console.error("Error en webhook MP:", err);
    res.sendStatus(200); // Igual respondemos 200 para que MP no reintente en loop
  }
});

// =====================================================
// RUTAS DE ADMIN
// =====================================================

app.post("/api/admin/login", auth.login);
app.post("/api/admin/logout", auth.logout);
app.get("/api/admin/me", auth.me);

// Traer todo (incluye pedidos) para el panel
app.get("/api/admin/store", auth.requireAdmin, (req, res) => {
  res.json(db.getStore());
});

// Editar configuración general del sitio: textos, colores, contacto, envíos
app.put("/api/admin/site", auth.requireAdmin, (req, res) => {
  const store = db.getStore();
  store.site = { ...store.site, ...req.body };
  db.saveStore(store);
  res.json(store.site);
});

// Categorías
app.put("/api/admin/categories", auth.requireAdmin, (req, res) => {
  const store = db.getStore();
  store.categories = req.body.categories || store.categories;
  db.saveStore(store);
  res.json(store.categories);
});

// Productos: crear
app.post("/api/admin/products", auth.requireAdmin, (req, res) => {
  const store = db.getStore();
  const product = {
    id: "p" + nanoid(8),
    name: req.body.name || "Producto sin nombre",
    category: req.body.category || store.categories[0]?.id,
    price: Number(req.body.price) || 0,
    description: req.body.description || "",
    images: req.body.images || [],
    colors: req.body.colors || [],
    sizes: req.body.sizes || [],
    active: req.body.active !== false,
  };
  store.products.push(product);
  db.saveStore(store);
  res.json(product);
});

// Productos: editar
app.put("/api/admin/products/:id", auth.requireAdmin, (req, res) => {
  const store = db.getStore();
  const idx = store.products.findIndex((p) => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Producto no encontrado." });
  store.products[idx] = { ...store.products[idx], ...req.body, id: store.products[idx].id };
  db.saveStore(store);
  res.json(store.products[idx]);
});

// Productos: eliminar
app.delete("/api/admin/products/:id", auth.requireAdmin, (req, res) => {
  const store = db.getStore();
  store.products = store.products.filter((p) => p.id !== req.params.id);
  db.saveStore(store);
  res.json({ ok: true });
});

// Subida de imágenes de producto
app.post("/api/admin/upload", auth.requireAdmin, upload.single("image"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No se recibió ninguna imagen." });
  res.json({ url: `/uploads/${req.file.filename}` });
});

// Pedidos: listar todos
app.get("/api/admin/orders", auth.requireAdmin, (req, res) => {
  const orders = db.getOrders().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(orders);
});

// Pedidos: cambiar estado
const VALID_STATUSES = ["PEDIDO RECIBIDO", "PREPARANDO", "ENVIADO", "ENTREGADO"];
app.put("/api/admin/orders/:id/status", auth.requireAdmin, (req, res) => {
  const { status } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: "Estado inválido." });
  }
  const orders = db.getOrders();
  const order = orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Pedido no encontrado." });
  order.status = status;
  db.saveOrders(orders);
  res.json(order);
});

// Errores de subida (Multer) con respuesta clara, sin stacktrace al cliente.
app.use((err, req, res, next) => {
  if (err) {
    const status = err.code === "LIMIT_FILE_SIZE" ? 413 : 400;
    return res.status(status).json({ error: err.message || "No se pudo procesar el archivo." });
  }
  next();
});

// Todo lo que no sea /api sirve el frontend (SPA)
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api")) return next();
  if (req.path.startsWith("/admin")) {
    return res.sendFile(path.join(__dirname, "..", "public", "admin.html"));
  }
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`KODO corriendo en http://localhost:${PORT}`);
  console.log(`Mercado Pago configurado: ${mp.isConfigured() ? "SÍ" : "NO (ver .env)"}`);
});
