const { MercadoPagoConfig, Preference, Payment } = require("mercadopago");

function getClient() {
  const accessToken = process.env.MP_ACCESS_TOKEN;
  if (!accessToken || accessToken.includes("TU_ACCESS_TOKEN")) {
    return null; // No configurado todavía
  }
  return new MercadoPagoConfig({ accessToken });
}

// Crea una preferencia de pago para un pedido y devuelve la URL de checkout (init_point)
async function createPreference(order) {
  const client = getClient();
  const publicUrl = process.env.PUBLIC_URL || "http://localhost:3000";

  if (!client) {
    // Mercado Pago no configurado: devolvemos null para que el server
    // pueda avisar al frontend que el pago todavía no está activo.
    return { initPoint: null, preferenceId: null, configured: false };
  }

  const preference = new Preference(client);

  const items = order.items.map((it) => ({
    id: it.productId,
    title: `${it.name} (${it.size} / ${it.color})`,
    quantity: it.qty,
    unit_price: Number(it.price),
    currency_id: "UYU",
  }));

  const response = await preference.create({
    body: {
      items,
      external_reference: order.id,
      back_urls: {
        success: `${publicUrl}/?order=${order.id}&status=success`,
        pending: `${publicUrl}/?order=${order.id}&status=pending`,
        failure: `${publicUrl}/?order=${order.id}&status=failure`,
      },
      auto_return: "approved",
      notification_url: `${publicUrl}/api/mp/webhook`,
      statement_descriptor: "KODO",
    },
  });

  return {
    initPoint: response.init_point,
    preferenceId: response.id,
    configured: true,
  };
}

// Consulta un pago por id para confirmar su estado (usado desde el webhook)
async function getPayment(paymentId) {
  const client = getClient();
  if (!client) return null;
  const payment = new Payment(client);
  return payment.get({ id: paymentId });
}

module.exports = { createPreference, getPayment, isConfigured: () => !!getClient() };
