(() => {
  "use strict";

  const root = document.getElementById("adminApp");
  let store = null;
  let orders = [];
  let activeTab = "general";

  init();

  async function init() {
    const meRes = await fetch("/api/admin/me").then((r) => r.json());
    if (!meRes.isAdmin) return renderLogin();
    await loadAll();
    renderShell();
  }

  async function loadAll() {
    store = await fetch("/api/admin/store").then((r) => r.json());
    orders = await fetch("/api/admin/orders").then((r) => r.json());
  }

  // ---------------------------------------------------------
  // Login
  // ---------------------------------------------------------
  function renderLogin() {
    root.innerHTML = `
      <div class="admin-login">
        <div class="admin-login__box">
          <h1>KODO ADMIN</h1>
          <p>Iniciá sesión para editar la tienda.</p>
          <form id="loginForm">
            <div class="afield"><label>Usuario</label><input type="text" name="user" required autofocus /></div>
            <div class="afield"><label>Contraseña</label><input type="password" name="pass" required /></div>
            <button class="btn btn-solid-dark btn-block" type="submit">ENTRAR</button>
          </form>
        </div>
      </div>
    `;
    document.getElementById("loginForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = new FormData(e.target);
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user: data.get("user"), pass: data.get("pass") }),
      });
      if (res.ok) {
        await loadAll();
        renderShell();
      } else {
        toast("Usuario o contraseña incorrectos.");
      }
    });
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    location.reload();
  }

  // ---------------------------------------------------------
  // Shell
  // ---------------------------------------------------------
  function renderShell() {
    root.innerHTML = `
      <div class="admin-shell">
        <aside class="admin-side">
          <div class="admin-side__logo">KODO ADMIN</div>
          <nav id="sideNav">
            <button data-tab="general">General y diseño</button>
            <button data-tab="categorias">Categorías</button>
            <button data-tab="productos">Productos</button>
            <button data-tab="pedidos">Pedidos</button>
          </nav>
          <button class="admin-side__logout" id="logoutBtn">Cerrar sesión</button>
        </aside>
        <main class="admin-main" id="adminMain"></main>
      </div>
    `;
    document.getElementById("logoutBtn").addEventListener("click", logout);
    root.querySelectorAll("#sideNav button").forEach((b) => {
      b.addEventListener("click", () => { activeTab = b.dataset.tab; renderTab(); });
    });
    renderTab();
  }

  function renderTab() {
    root.querySelectorAll("#sideNav button").forEach((b) => b.classList.toggle("active", b.dataset.tab === activeTab));
    const main = document.getElementById("adminMain");
    if (activeTab === "general") return renderGeneral(main);
    if (activeTab === "categorias") return renderCategorias(main);
    if (activeTab === "productos") return renderProductos(main);
    if (activeTab === "pedidos") return renderPedidos(main);
  }

  // ---------------------------------------------------------
  // General (textos, colores, contacto, envíos)
  // ---------------------------------------------------------
  function renderGeneral(main) {
    const s = store.site;
    main.innerHTML = `
      <h1>General y diseño</h1>
      <p class="sub">Acá controlás todo lo que ve el visitante: textos, colores, contacto y zonas de envío.</p>

      <div class="admin-card">
        <h2>Marca y textos</h2>
        <div class="afield"><label>Nombre de marca</label><input id="f_brand" value="${attr(s.brand)}" /></div>
        <div class="afield"><label>Bajada (arriba del header, opcional)</label><input id="f_tagline" value="${attr(s.tagline)}" /></div>
        <div class="admin-grid2">
          <div class="afield"><label>Título del hero</label><input id="f_heroTitle" value="${attr(s.texts.heroTitle)}" /></div>
          <div class="afield"><label>Subtítulo del hero</label><input id="f_heroSubtitle" value="${attr(s.texts.heroSubtitle)}" /></div>
          <div class="afield"><label>Texto botón tienda</label><input id="f_heroCtaShop" value="${attr(s.texts.heroCtaShop)}" /></div>
          <div class="afield"><label>Texto botón contacto</label><input id="f_heroCtaContact" value="${attr(s.texts.heroCtaContact)}" /></div>
        </div>
        <div class="afield"><label>Foto de fondo del hero (URL)</label><input id="f_heroImage" value="${attr(s.heroImage || "")}" placeholder="https://..." /></div>
        <div class="afield">
          <label>O subir foto del hero</label>
          <input type="file" id="f_heroImageFile" accept="image/*" />
        </div>
        <div class="afield"><label>Texto intro sección tienda</label><textarea id="f_shopIntro" rows="2">${text(s.texts.shopIntro)}</textarea></div>
        <div class="afield"><label>Nota de envío (se muestra en carrito y checkout)</label><textarea id="f_shippingNote" rows="3">${text(s.texts.shippingNote)}</textarea></div>
        <div class="afield"><label>Nota del footer</label><input id="f_footerNote" value="${attr(s.texts.footerNote)}" /></div>
      </div>

      <div class="admin-card">
        <h2>Colores de marca</h2>
        <div class="admin-grid2">
          ${colorField("Negro", "f_black", s.colors.black)}
          ${colorField("Beige / crema", "f_cream", s.colors.cream)}
          ${colorField("Beige secundario", "f_sand", s.colors.sand)}
          ${colorField("Blanco (texto sobre negro)", "f_white", s.colors.white)}
          ${colorField("Líneas / bordes", "f_line", s.colors.line)}
        </div>
      </div>

      <div class="admin-card">
        <h2>Contacto</h2>
        <div class="admin-grid2">
          <div class="afield"><label>WhatsApp (número con código de país, sin +, ej 5989XXXXXXX)</label><input id="f_whatsapp" value="${attr(s.contact.whatsapp)}" placeholder="Todavía sin número" /></div>
          <div class="afield"><label>Instagram (usuario sin @)</label><input id="f_instagram" value="${attr(s.contact.instagram)}" /></div>
          <div class="afield"><label>Email</label><input id="f_email" value="${attr(s.contact.email)}" /></div>
        </div>
      </div>

      <div class="admin-card">
        <h2>Zonas y precios de envío</h2>
        <div id="zonesEditor"></div>
        <div class="admin-btn-row"><button class="btn btn-outline-dark" id="addZoneBtn" type="button">+ Agregar zona</button></div>
      </div>

      <div class="admin-btn-row">
        <button class="btn btn-solid-dark" id="saveGeneralBtn">GUARDAR CAMBIOS</button>
      </div>
    `;

    renderZonesEditor(s.shippingZones);
    document.getElementById("addZoneBtn").addEventListener("click", () => {
      s.shippingZones.push({ id: "zona" + Date.now(), name: "Nueva zona", price: 0 });
      renderZonesEditor(s.shippingZones);
    });
    document.getElementById("saveGeneralBtn").addEventListener("click", () => saveGeneral(s));

    document.getElementById("f_heroImageFile").addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const url = await uploadImage(file);
      if (url) document.getElementById("f_heroImage").value = url;
    });
  }

  function colorField(label, id, value) {
    return `
      <div class="afield">
        <label>${label}</label>
        <div class="color-row">
          <input type="color" id="${id}_picker" value="${value}" />
          <input type="text" id="${id}" value="${value}" />
        </div>
      </div>
    `;
  }

  function renderZonesEditor(zones) {
    const el = document.getElementById("zonesEditor");
    el.innerHTML = zones.map((z, i) => `
      <div class="admin-grid2" style="margin-bottom:8px" data-zi="${i}">
        <div class="afield"><label>Nombre</label><input class="zname" value="${attr(z.name)}" /></div>
        <div class="afield"><label>Precio ($U)</label><input class="zprice" type="number" value="${z.price}" /></div>
      </div>
    `).join("");
  }

  function collectZones() {
    return [...document.querySelectorAll("#zonesEditor [data-zi]")].map((row) => ({
      id: "zona" + row.dataset.zi + "_" + Date.now(),
      name: row.querySelector(".zname").value,
      price: Number(row.querySelector(".zprice").value) || 0,
    })).map((z, i) => ({ ...z, id: store.site.shippingZones[i]?.id || z.id }));
  }

  async function saveGeneral(s) {
    // Sincronizar pickers de color con inputs de texto
    ["f_black", "f_cream", "f_sand", "f_white", "f_line"].forEach((id) => {
      const picker = document.getElementById(id + "_picker");
      const text = document.getElementById(id);
      if (picker.value !== text.value && document.activeElement === picker) text.value = picker.value;
    });

    const payload = {
      brand: val("f_brand"),
      tagline: val("f_tagline"),
      heroImage: val("f_heroImage"),
      texts: {
        heroTitle: val("f_heroTitle"),
        heroSubtitle: val("f_heroSubtitle"),
        heroCtaShop: val("f_heroCtaShop"),
        heroCtaContact: val("f_heroCtaContact"),
        shopIntro: val("f_shopIntro"),
        shippingNote: val("f_shippingNote"),
        footerNote: val("f_footerNote"),
      },
      colors: {
        black: val("f_black"), cream: val("f_cream"), sand: val("f_sand"), white: val("f_white"), line: val("f_line"),
      },
      contact: {
        whatsapp: val("f_whatsapp").replace(/[^0-9]/g, ""),
        instagram: val("f_instagram").replace("@", ""),
        email: val("f_email"),
      },
      shippingZones: collectZones(),
    };

    const res = await fetch("/api/admin/site", {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload),
    });
    if (res.ok) {
      store.site = await res.json();
      toast("Cambios guardados.");
    } else {
      toast("No se pudo guardar.");
    }
  }

  // sync color pickers live
  document.addEventListener("input", (e) => {
    if (e.target.id?.endsWith("_picker")) {
      const textInput = document.getElementById(e.target.id.replace("_picker", ""));
      if (textInput) textInput.value = e.target.value;
    }
  });

  // ---------------------------------------------------------
  // Categorías
  // ---------------------------------------------------------
  function renderCategorias(main) {
    main.innerHTML = `
      <h1>Categorías</h1>
      <p class="sub">Las categorías organizan la tienda. "Novedades" siempre muestra todo junto, no hace falta crearla.</p>
      <div class="admin-card">
        <div id="catList"></div>
        <div class="admin-btn-row"><button class="btn btn-outline-dark" id="addCatBtn" type="button">+ Agregar categoría</button></div>
        <div class="admin-btn-row"><button class="btn btn-solid-dark" id="saveCatBtn">GUARDAR CATEGORÍAS</button></div>
      </div>
    `;
    renderCatList();
    document.getElementById("addCatBtn").addEventListener("click", () => {
      store.categories.push({ id: "cat" + Date.now(), name: "Nueva categoría" });
      renderCatList();
    });
    document.getElementById("saveCatBtn").addEventListener("click", saveCategorias);
  }
  function renderCatList() {
    document.getElementById("catList").innerHTML = store.categories.map((c, i) => `
      <div class="admin-grid2" style="margin-bottom:8px" data-ci="${i}">
        <div class="afield"><label>Nombre visible</label><input class="cname" value="${attr(c.name)}" /></div>
        <div class="afield"><label>ID interno (sin espacios)</label><input class="cid" value="${attr(c.id)}" /></div>
      </div>
    `).join("");
  }
  async function saveCategorias() {
    const cats = [...document.querySelectorAll("#catList [data-ci]")].map((row) => ({
      id: row.querySelector(".cid").value.trim(),
      name: row.querySelector(".cname").value.trim(),
    }));
    const res = await fetch("/api/admin/categories", {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ categories: cats }),
    });
    if (res.ok) { store.categories = await res.json(); toast("Categorías guardadas."); }
  }

  // ---------------------------------------------------------
  // Productos
  // ---------------------------------------------------------
  function renderProductos(main) {
    main.innerHTML = `
      <h1>Productos</h1>
      <p class="sub">Agregá, editá o eliminá productos de la tienda.</p>
      <div class="admin-btn-row" style="margin-bottom:16px">
        <button class="btn btn-solid-dark" id="newProductBtn">+ NUEVO PRODUCTO</button>
      </div>
      <div class="admin-card" style="overflow-x:auto">
        <table class="ptable">
          <thead><tr><th></th><th>Nombre</th><th>Categoría</th><th>Precio</th><th>Activo</th><th></th></tr></thead>
          <tbody id="prodBody"></tbody>
        </table>
      </div>
    `;
    document.getElementById("newProductBtn").addEventListener("click", () => openProductModal(null));
    renderProdBody();
  }

  function renderProdBody() {
    const catName = (id) => store.categories.find((c) => c.id === id)?.name || id;
    document.getElementById("prodBody").innerHTML = store.products.map((p) => `
      <tr data-id="${p.id}">
        <td>${p.images?.[0] ? `<img src="${p.images[0]}" />` : ""}</td>
        <td>${text(p.name)}</td>
        <td>${text(catName(p.category))}</td>
        <td>${money(p.price)}</td>
        <td>${p.active ? "Sí" : "No"}</td>
        <td class="actions">
          <button data-act="edit">Editar</button>
          <button data-act="del">Eliminar</button>
        </td>
      </tr>
    `).join("");
    document.querySelectorAll("#prodBody tr").forEach((row) => {
      const id = row.dataset.id;
      row.querySelector('[data-act="edit"]').addEventListener("click", () => openProductModal(id));
      row.querySelector('[data-act="del"]').addEventListener("click", () => deleteProduct(id));
    });
  }

  async function deleteProduct(id) {
    if (!confirm("¿Eliminar este producto?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    store.products = store.products.filter((p) => p.id !== id);
    renderProdBody();
    toast("Producto eliminado.");
  }

  function openProductModal(id) {
    const p = id ? store.products.find((x) => x.id === id) : {
      name: "", category: store.categories[0]?.id || "", price: 0, description: "",
      images: [], colors: [], sizes: [], active: true,
    };
    const scrim = document.createElement("div");
    scrim.className = "modal-scrim";
    scrim.innerHTML = `
      <div class="modal-box">
        <h3>${id ? "Editar producto" : "Nuevo producto"}</h3>
        <div class="afield"><label>Nombre</label><input id="p_name" value="${attr(p.name)}" /></div>
        <div class="admin-grid2">
          <div class="afield"><label>Categoría</label>
            <select id="p_category">${store.categories.map((c) => `<option value="${c.id}" ${c.id === p.category ? "selected" : ""}>${text(c.name)}</option>`).join("")}</select>
          </div>
          <div class="afield"><label>Precio ($U)</label><input id="p_price" type="number" value="${p.price}" /></div>
        </div>
        <div class="afield"><label>Descripción</label><textarea id="p_desc" rows="3">${text(p.description)}</textarea></div>

        <div class="afield">
          <label>Fotos</label>
          <div class="thumb-row" id="p_thumbs"></div>
          <input type="file" id="p_file" accept="image/*" multiple />
        </div>

        <div class="afield">
          <label>Colores disponibles</label>
          <div class="chip-editor" id="p_colors"></div>
          <input type="text" id="p_colorInput" placeholder="Escribí un color y presioná Enter" />
        </div>
        <div class="afield">
          <label>Talles disponibles</label>
          <div class="chip-editor" id="p_sizes"></div>
          <input type="text" id="p_sizeInput" placeholder="Escribí un talle y presioná Enter" />
        </div>

        <div class="afield">
          <label><input type="checkbox" id="p_active" ${p.active ? "checked" : ""} style="width:auto;margin-right:8px" />Producto activo (visible en la tienda)</label>
        </div>

        <div class="admin-btn-row">
          <button class="btn btn-solid-dark" id="p_save">GUARDAR</button>
          <button class="btn btn-outline-dark" id="p_cancel" type="button">CANCELAR</button>
        </div>
      </div>
    `;
    document.body.appendChild(scrim);

    let images = [...(p.images || [])];
    let colors = [...(p.colors || [])];
    let sizes = [...(p.sizes || [])];

    const renderThumbs = () => {
      scrim.querySelector("#p_thumbs").innerHTML = images.map((url, i) => `
        <div class="thumb"><img src="${url}" /><button data-i="${i}">×</button></div>
      `).join("");
      scrim.querySelectorAll(".thumb button").forEach((b) => b.addEventListener("click", () => {
        images.splice(Number(b.dataset.i), 1); renderThumbs();
      }));
    };
    const renderChips = (containerId, arr, onRemove) => {
      scrim.querySelector(containerId).innerHTML = arr.map((v, i) => `<span class="chip">${text(v)}<button data-i="${i}">×</button></span>`).join("");
      scrim.querySelectorAll(`${containerId} button`).forEach((b) => b.addEventListener("click", () => { onRemove(Number(b.dataset.i)); }));
    };
    const refreshColors = () => renderChips("#p_colors", colors, (i) => { colors.splice(i, 1); refreshColors(); });
    const refreshSizes = () => renderChips("#p_sizes", sizes, (i) => { sizes.splice(i, 1); refreshSizes(); });

    renderThumbs(); refreshColors(); refreshSizes();

    scrim.querySelector("#p_file").addEventListener("change", async (e) => {
      for (const file of e.target.files) {
        const url = await uploadImage(file);
        if (url) images.push(url);
      }
      renderThumbs();
    });
    scrim.querySelector("#p_colorInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.value.trim()) { e.preventDefault(); colors.push(e.target.value.trim()); e.target.value = ""; refreshColors(); }
    });
    scrim.querySelector("#p_sizeInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.value.trim()) { e.preventDefault(); sizes.push(e.target.value.trim()); e.target.value = ""; refreshSizes(); }
    });

    scrim.querySelector("#p_cancel").addEventListener("click", () => scrim.remove());
    scrim.querySelector("#p_save").addEventListener("click", async () => {
      const payload = {
        name: scrim.querySelector("#p_name").value.trim(),
        category: scrim.querySelector("#p_category").value,
        price: Number(scrim.querySelector("#p_price").value) || 0,
        description: scrim.querySelector("#p_desc").value.trim(),
        images, colors, sizes,
        active: scrim.querySelector("#p_active").checked,
      };
      let saved;
      if (id) {
        saved = await fetch(`/api/admin/products/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }).then((r) => r.json());
        const idx = store.products.findIndex((x) => x.id === id);
        store.products[idx] = saved;
      } else {
        saved = await fetch(`/api/admin/products`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }).then((r) => r.json());
        store.products.push(saved);
      }
      scrim.remove();
      renderProdBody();
      toast("Producto guardado.");
    });
  }

  async function uploadImage(file) {
    const fd = new FormData();
    fd.append("image", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    if (!res.ok) { toast("No se pudo subir la imagen."); return null; }
    const data = await res.json();
    return data.url;
  }

  // ---------------------------------------------------------
  // Pedidos
  // ---------------------------------------------------------
  const STATUSES = ["PEDIDO RECIBIDO", "PREPARANDO", "ENVIADO", "ENTREGADO"];

  function renderPedidos(main) {
    main.innerHTML = `
      <h1>Pedidos</h1>
      <p class="sub">Gestioná el estado de cada pedido. El cliente lo ve en tiempo real en "Seguimiento".</p>
      <div class="admin-card" style="overflow-x:auto">
        <table class="ptable">
          <thead><tr><th>N°</th><th>Cliente</th><th>Total</th><th>Pagado</th><th>Estado</th><th>Fecha</th></tr></thead>
          <tbody id="orderBody"></tbody>
        </table>
      </div>
    `;
    document.getElementById("orderBody").innerHTML = orders.length ? orders.map((o) => `
      <tr data-id="${o.id}">
        <td>${o.id}</td>
        <td>${text(o.customer.name)}<br><span style="color:#8a8377">${text(o.customer.phone)}</span></td>
        <td>${money(o.total)}</td>
        <td>${o.paid ? "Sí" : "No"}</td>
        <td>
          <select class="status-select" data-id="${o.id}">
            ${STATUSES.map((s) => `<option value="${s}" ${s === o.status ? "selected" : ""}>${s}</option>`).join("")}
          </select>
        </td>
        <td>${new Date(o.createdAt).toLocaleDateString("es-UY")}</td>
      </tr>
    `).join("") : `<tr><td colspan="6" style="color:#8a8377;padding:20px 8px">Todavía no hay pedidos.</td></tr>`;

    document.querySelectorAll(".status-select").forEach((sel) => {
      sel.addEventListener("change", async () => {
        const id = sel.dataset.id;
        const res = await fetch(`/api/admin/orders/${id}/status`, {
          method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: sel.value }),
        });
        if (res.ok) toast(`Pedido ${id} actualizado.`);
      });
    });
  }

  // ---------------------------------------------------------
  // Utils
  // ---------------------------------------------------------
  function val(id) { return document.getElementById(id).value.trim(); }
  function text(s) { return String(s ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c])); }
  function attr(s) { return text(s).replace(/"/g, "&quot;"); }
  function money(n) { return "$U " + Number(n || 0).toLocaleString("es-UY"); }
  let toastTimer;
  function toast(msg) {
    const t = document.getElementById("toast");
    t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 3000);
  }
})();
