(() => {
  "use strict";

  const STATUS_STEPS = ["PEDIDO RECIBIDO", "PREPARANDO", "ENVIADO", "ENTREGADO"];

  const state = {
    store: null,
    cart: loadCart(),
    productPanelOpen: false,
  };

  const app = document.getElementById("app");

  // ---------------------------------------------------------
  // Arranque
  // ---------------------------------------------------------
  init();

  async function init() {
    bindChrome();
    await loadStore();
    window.addEventListener("hashchange", route);
    route();
    handleMpReturn();
  }

  async function loadStore() {
    const res = await fetch("/api/store");
    state.store = await res.json();
    applySiteConfig(state.store.site);
    renderFooter(state.store.site);
    updateCartCount();
  }

  function applySiteConfig(site) {
    const root = document.documentElement.style;
    root.setProperty("--black", site.colors.black);
    root.setProperty("--cream", site.colors.cream);
    root.setProperty("--sand", site.colors.sand);
    root.setProperty("--white", site.colors.white);
    root.setProperty("--line", site.colors.line);
    document.title = `${site.brand} — Streetwear Oversize`;
    renderMarquee(site);
    renderPromoBar(site);
  }

  function renderMarquee(site) {
    const unit = `${esc(site.brand)} •&nbsp;&nbsp;`.repeat(8);
    const track = document.getElementById("marqueeTrack");
    track.innerHTML = `<span>${unit}</span><span>${unit}</span>`;
  }

  function renderPromoBar(site) {
    const bar = document.getElementById("promoBar");
    if (site.tagline) {
      bar.textContent = site.tagline;
      bar.classList.remove("hidden");
    } else {
      bar.classList.add("hidden");
    }
  }

  function renderFooter(site) {
    document.getElementById("footerLogo").textContent = site.brand;
    document.getElementById("footerNote").textContent = site.texts.footerNote || "";
    document.getElementById("footerYear").textContent = new Date().getFullYear();
    const links = document.getElementById("footerLinks");
    const igLink = site.contact.instagram ? `https://instagram.com/${site.contact.instagram}` : "#/contacto";
    links.innerHTML = `
      ${site.contact.instagram ? `<a href="${igLink}" target="_blank" rel="noopener">Instagram</a>` : ""}
      ${site.contact.whatsapp ? `<a href="https://wa.me/${site.contact.whatsapp}" target="_blank" rel="noopener">WhatsApp</a>` : ""}
      <a href="mailto:${site.contact.email}">${site.contact.email}</a>
    `;
  }

  // ---------------------------------------------------------
  // Chrome: menú mobile, carrito
  // ---------------------------------------------------------
  function bindChrome() {
    const menuToggle = document.getElementById("menuToggle");
    const navMobile = document.getElementById("navMobile");
    const navClose = document.getElementById("navMobileClose");
    const scrim = document.getElementById("scrim");

    const openMenu = () => { navMobile.classList.add("open"); scrim.classList.add("open"); };
    const closeMenu = () => { navMobile.classList.remove("open"); scrim.classList.remove("open"); };
    menuToggle.addEventListener("click", openMenu);
    navClose.addEventListener("click", closeMenu);
    scrim.addEventListener("click", () => { closeMenu(); closeCart(); closePanel(); });
    navMobile.querySelectorAll("a").forEach((a) => a.addEventListener("click", closeMenu));

    document.getElementById("cartToggle").addEventListener("click", openCart);
    document.getElementById("cartClose").addEventListener("click", closeCart);
  }

  function openCart() {
    document.getElementById("cartDrawer").classList.add("open");
    document.getElementById("scrim").classList.add("open");
    renderCart();
  }
  function closeCart() {
    document.getElementById("cartDrawer").classList.remove("open");
    document.getElementById("scrim").classList.remove("open");
  }
  function closePanel() {
    document.getElementById("productPanel").classList.remove("open");
  }

  // ---------------------------------------------------------
  // Router
  // ---------------------------------------------------------
  function route() {
    const hash = location.hash.replace(/^#/, "") || "/";
    const parts = hash.split("/").filter(Boolean);

    if (parts.length === 0) return renderHome();
    if (parts[0] === "tienda") return renderShop(parts[1] || "novedades");
    if (parts[0] === "producto") return renderShop("novedades", parts[1]);
    if (parts[0] === "checkout") return renderCheckout();
    if (parts[0] === "seguimiento") return renderTracking(parts[1]);
    if (parts[0] === "contacto") return renderContact();
    if (parts[0] === "legales") return renderLegal(parts[1]);
    return renderHome();
  }

  window.scrollAppTop = () => window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });

  // ---------------------------------------------------------
  // Vista: HOME
  // ---------------------------------------------------------
  function renderHome() {
    const { site, products } = state.store;
    const featured = products.filter((p) => p.active).slice(0, 4);

    app.innerHTML = `
      <section class="hero">
        <div class="hero__media ${site.heroImage ? "" : "is-placeholder"}" style="${site.heroImage ? `--hero-img:url('${site.heroImage}')` : ""}">
          ${!site.heroImage ? `<div class="hero__placeholder-tag">Foto hero — el admin puede subir una</div>` : ""}
        </div>
        <div class="hero__content">
          <h1 class="hero__title">${esc(site.texts.heroTitle)}</h1>
          <p class="hero__subtitle">${esc(site.texts.heroSubtitle)}</p>
          <div class="hero__ctas">
            <a href="#/tienda/novedades" class="btn btn-solid-light">${esc(site.texts.heroCtaShop)}</a>
            <a href="#/contacto" class="btn btn-outline-light">${esc(site.texts.heroCtaContact)}</a>
          </div>
        </div>
      </section>

      <section class="section">
        <div class="container">
          <div class="section-head">
            <h2 class="section-title">Novedades</h2>
            <a href="#/tienda/novedades" class="btn btn-outline-dark">Ver todo</a>
          </div>
          <p class="section-intro">${esc(site.texts.shopIntro || "")}</p>
          <div class="grid" style="margin-top:28px" id="homeGrid"></div>
        </div>
      </section>

      <section class="section section-alt">
        <div class="container">
          <div class="section-head"><h2 class="section-title">Contacto</h2></div>
          ${contactCardsHtml(site)}
        </div>
      </section>
    `;
    renderProductGrid(document.getElementById("homeGrid"), featured);
    scrollAppTop();
  }

  // ---------------------------------------------------------
  // Vista: TIENDA
  // ---------------------------------------------------------
  function renderShop(categoryId, openProductId) {
    const { site, products, categories } = state.store;
    const isNovedades = categoryId === "novedades";
    const list = products.filter((p) => p.active && (isNovedades || p.category === categoryId));
    const catName = isNovedades ? "Novedades" : (categories.find((c) => c.id === categoryId)?.name || "Tienda");

    app.innerHTML = `
      <section class="section">
        <div class="container">
          <div class="section-head"><h2 class="section-title">${esc(catName)}</h2></div>
          <div class="cat-strip">
            <a href="#/tienda/novedades" class="cat-pill ${isNovedades ? "active" : ""}">Novedades</a>
            ${categories.map((c) => `<a href="#/tienda/${c.id}" class="cat-pill ${c.id === categoryId ? "active" : ""}">${esc(c.name)}</a>`).join("")}
          </div>
          <div class="grid" id="shopGrid"></div>
        </div>
      </section>
    `;
    const grid = document.getElementById("shopGrid");
    if (list.length === 0) {
      grid.outerHTML = `<div class="empty-state">Todavía no hay productos acá. Volvé pronto.</div>`;
    } else {
      renderProductGrid(grid, list);
    }
    scrollAppTop();
    if (openProductId) openProductPanel(openProductId);
  }

  function renderProductGrid(container, list) {
    container.innerHTML = list.map((p, i) => `
      <div class="card" style="animation-delay:${Math.min(i, 8) * 45}ms" data-id="${p.id}">
        <div class="card__img ${p.images?.[0] ? "" : "placeholder"}">
          ${p.images?.[0] ? `<img src="${p.images[0]}" alt="${esc(p.name)}" />` : `<span>${esc(p.name)}</span>`}
        </div>
        <p class="card__name">${esc(p.name)}</p>
        <p class="card__price">${money(p.price)}</p>
      </div>
    `).join("");
    container.querySelectorAll(".card").forEach((el) => {
      el.addEventListener("click", () => openProductPanel(el.dataset.id));
    });
  }

  // ---------------------------------------------------------
  // Panel de producto
  // ---------------------------------------------------------
  let panelSelection = { color: null, size: null, qty: 1 };

  function openProductPanel(productId) {
    const product = state.store.products.find((p) => p.id === productId);
    if (!product) return;
    panelSelection = { color: product.colors?.[0] || null, size: product.sizes?.[0] || null, qty: 1 };

    const panel = document.getElementById("productPanel");
    panel.innerHTML = productPanelHtml(product);
    panel.classList.add("open");
    document.getElementById("scrim").classList.add("open");

    panel.querySelector(".panel__close button").addEventListener("click", () => {
      closePanel();
      document.getElementById("scrim").classList.remove("open");
    });

    panel.querySelectorAll("[data-color]").forEach((btn) => btn.addEventListener("click", () => {
      panelSelection.color = btn.dataset.color;
      panel.querySelectorAll("[data-color]").forEach((b) => b.classList.toggle("selected", b.dataset.color === panelSelection.color));
    }));
    panel.querySelectorAll("[data-size]").forEach((btn) => btn.addEventListener("click", () => {
      panelSelection.size = btn.dataset.size;
      panel.querySelectorAll("[data-size]").forEach((b) => b.classList.toggle("selected", b.dataset.size === panelSelection.size));
    }));
    panel.querySelector("#qtyMinus").addEventListener("click", () => {
      panelSelection.qty = Math.max(1, panelSelection.qty - 1);
      panel.querySelector("#qtyVal").textContent = panelSelection.qty;
    });
    panel.querySelector("#qtyPlus").addEventListener("click", () => {
      panelSelection.qty += 1;
      panel.querySelector("#qtyVal").textContent = panelSelection.qty;
    });
    panel.querySelector("#addToCartBtn").addEventListener("click", () => {
      addToCart(product, panelSelection.color, panelSelection.size, panelSelection.qty);
      closePanel();
      document.getElementById("scrim").classList.remove("open");
      showToast(`${product.name} agregado al carrito`);
      openCart();
    });
  }

  function productPanelHtml(p) {
    return `
      <div class="panel__close"><button aria-label="Cerrar">×</button></div>
      <div class="panel__img">
        ${p.images?.[0] ? `<img src="${p.images[0]}" alt="${esc(p.name)}" />` : `<div class="card__img placeholder" style="height:100%"><span>${esc(p.name)}</span></div>`}
      </div>
      <div class="panel__body">
        <h2 class="panel__name">${esc(p.name)}</h2>
        <p class="panel__price">${money(p.price)}</p>
        <p class="panel__desc">${esc(p.description || "")}</p>
        ${p.colors?.length ? `
        <div class="option-group">
          <span class="option-label">COLOR</span>
          <div class="option-list">
            ${p.colors.map((c, i) => `<button class="option-chip ${i === 0 ? "selected" : ""}" data-color="${esc(c)}">${esc(c)}</button>`).join("")}
          </div>
        </div>` : ""}
        ${p.sizes?.length ? `
        <div class="option-group">
          <span class="option-label">TALLE</span>
          <div class="option-list">
            ${p.sizes.map((s, i) => `<button class="option-chip ${i === 0 ? "selected" : ""}" data-size="${esc(s)}">${esc(s)}</button>`).join("")}
          </div>
        </div>` : ""}
        <div class="option-group">
          <span class="option-label">CANTIDAD</span>
          <div class="qty-row">
            <button class="qty-btn" id="qtyMinus">−</button>
            <span class="qty-val" id="qtyVal">1</span>
            <button class="qty-btn" id="qtyPlus">+</button>
          </div>
        </div>
        <button class="btn btn-solid-dark btn-block" id="addToCartBtn">AGREGAR AL CARRITO</button>
      </div>
    `;
  }

  // ---------------------------------------------------------
  // Carrito
  // ---------------------------------------------------------
  function loadCart() {
    try { return JSON.parse(localStorage.getItem("kodo_cart") || "[]"); } catch { return []; }
  }
  function saveCart() {
    localStorage.setItem("kodo_cart", JSON.stringify(state.cart));
    updateCartCount();
  }
  function updateCartCount() {
    const count = state.cart.reduce((n, it) => n + it.qty, 0);
    const badge = document.getElementById("cartCount");
    badge.textContent = count;
    badge.classList.toggle("hidden", count === 0);
  }

  function addToCart(product, color, size, qty) {
    const key = `${product.id}__${color}__${size}`;
    const existing = state.cart.find((it) => it.key === key);
    if (existing) {
      existing.qty += qty;
    } else {
      state.cart.push({
        key, productId: product.id, name: product.name, price: product.price,
        image: product.images?.[0] || null, color, size, qty,
      });
    }
    saveCart();
  }

  function renderCart() {
    const itemsEl = document.getElementById("cartItems");
    const footEl = document.getElementById("cartFoot");

    if (state.cart.length === 0) {
      itemsEl.innerHTML = `<div class="empty-state">Tu carrito está vacío.</div>`;
      footEl.innerHTML = "";
      return;
    }

    itemsEl.innerHTML = state.cart.map((it) => `
      <div class="cart-item" data-key="${it.key}">
        <div class="cart-item__img">${it.image ? `<img src="${it.image}" alt="">` : ""}</div>
        <div class="cart-item__info">
          <p class="cart-item__name">${esc(it.name)}</p>
          <p class="cart-item__meta">${esc(it.size || "")} ${it.color ? "· " + esc(it.color) : ""}</p>
          <div class="cart-item__row">
            <div class="cart-item__qty">
              <button data-act="minus">−</button>
              <span>${it.qty}</span>
              <button data-act="plus">+</button>
            </div>
            <span class="cart-item__price">${money(it.price * it.qty)}</span>
          </div>
          <button class="cart-item__remove" data-act="remove">Eliminar</button>
        </div>
      </div>
    `).join("");

    itemsEl.querySelectorAll(".cart-item").forEach((row) => {
      const key = row.dataset.key;
      row.querySelector('[data-act="minus"]').addEventListener("click", () => changeQty(key, -1));
      row.querySelector('[data-act="plus"]').addEventListener("click", () => changeQty(key, 1));
      row.querySelector('[data-act="remove"]').addEventListener("click", () => removeItem(key));
    });

    const subtotal = state.cart.reduce((sum, it) => sum + it.price * it.qty, 0);
    footEl.innerHTML = `
      <div class="drawer__totalrow"><span>Subtotal</span><strong>${money(subtotal)}</strong></div>
      <p class="drawer__shipnote">${esc(state.store.site.texts.shippingNote)}</p>
      <a href="#/checkout" class="btn btn-solid-dark btn-block" id="goCheckout">FINALIZAR COMPRA</a>
    `;
    footEl.querySelector("#goCheckout").addEventListener("click", closeCart);
  }

  function changeQty(key, delta) {
    const item = state.cart.find((it) => it.key === key);
    if (!item) return;
    item.qty = Math.max(1, item.qty + delta);
    saveCart();
    renderCart();
  }
  function removeItem(key) {
    state.cart = state.cart.filter((it) => it.key !== key);
    saveCart();
    renderCart();
  }

  // ---------------------------------------------------------
  // Vista: CHECKOUT
  // ---------------------------------------------------------
  function renderCheckout() {
    const { site } = state.store;
    if (state.cart.length === 0) {
      app.innerHTML = `<div class="form-page"><h1>Checkout</h1><p class="lead">Tu carrito está vacío.</p><a href="#/tienda/novedades" class="btn btn-solid-dark">Ir a la tienda</a></div>`;
      scrollAppTop();
      return;
    }
    const subtotal = state.cart.reduce((sum, it) => sum + it.price * it.qty, 0);
    const zones = site.shippingZones;

    app.innerHTML = `
      <div class="form-page">
        <h1>Finalizar compra</h1>
        <p class="lead">Completá tus datos. El envío se coordina y se paga al recibir el pedido.</p>

        <form id="checkoutForm">
          <div class="field"><label>Nombre completo</label><input type="text" name="name" required /></div>
          <div class="field"><label>Teléfono</label><input type="tel" name="phone" required placeholder="09X XXX XXX" /></div>
          <div class="field"><label>Dirección</label><input type="text" name="address" required /></div>
          <div class="field"><label>Localidad / Departamento</label><input type="text" name="locality" required /></div>
          <div class="field"><label>Instrucciones de entrega (opcional)</label><textarea name="instructions" rows="3" placeholder="Referencias, horarios, etc."></textarea></div>

          <div class="field">
            <label>Zona de envío</label>
            <div class="zone-options" id="zoneOptions">
              ${zones.map((z, i) => `
                <label class="zone-option ${i === 0 ? "selected" : ""}">
                  <span>${esc(z.name)}</span>
                  <span>${money(z.price)}</span>
                  <input type="radio" name="zone" value="${z.id}" ${i === 0 ? "checked" : ""} style="display:none" />
                </label>
              `).join("")}
            </div>
          </div>

          <div class="checkout-summary">
            <div class="summary-row"><span>Subtotal</span><span>${money(subtotal)}</span></div>
            <div class="summary-row"><span>Envío (se paga al recibir)</span><span id="zonePriceLabel">${money(zones[0]?.price || 0)}</span></div>
            <div class="summary-row total"><span>Total a pagar ahora</span><span>${money(subtotal)}</span></div>
          </div>

          <div class="notice">${esc(site.texts.shippingNote)}</div>

          <button type="submit" class="btn btn-solid-dark btn-block" id="submitOrderBtn">PAGAR CON MERCADO PAGO</button>
        </form>
      </div>
    `;
    scrollAppTop();

    const zoneOptions = document.getElementById("zoneOptions");
    zoneOptions.querySelectorAll(".zone-option").forEach((opt) => {
      opt.addEventListener("click", () => {
        zoneOptions.querySelectorAll(".zone-option").forEach((o) => o.classList.remove("selected"));
        opt.classList.add("selected");
        opt.querySelector('input[type=radio]').checked = true;
        const zoneId = opt.querySelector('input[type=radio]').value;
        const zone = zones.find((z) => z.id === zoneId);
        document.getElementById("zonePriceLabel").textContent = money(zone.price);
      });
    });

    document.getElementById("checkoutForm").addEventListener("submit", submitOrder);
  }

  async function submitOrder(e) {
    e.preventDefault();
    const form = e.target;
    const btn = document.getElementById("submitOrderBtn");
    btn.disabled = true;
    btn.textContent = "PROCESANDO...";

    const data = new FormData(form);
    const payload = {
      items: state.cart.map((it) => ({ productId: it.productId, size: it.size, color: it.color, qty: it.qty })),
      customer: {
        name: data.get("name"),
        phone: data.get("phone"),
        address: data.get("address"),
        locality: data.get("locality"),
        instructions: data.get("instructions"),
      },
      shippingZoneId: data.get("zone"),
    };

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Error al crear el pedido");

      state.cart = [];
      saveCart();

      if (result.checkoutUrl) {
        localStorage.setItem("kodo_last_order", result.orderId);
        window.location.href = result.checkoutUrl;
      } else {
        // Mercado Pago todavía no está configurado en el servidor
        app.innerHTML = orderCreatedNoMpHtml(result.orderId, result.total);
        scrollAppTop();
      }
    } catch (err) {
      showToast(err.message || "No se pudo procesar el pedido");
      btn.disabled = false;
      btn.textContent = "PAGAR CON MERCADO PAGO";
    }
  }

  function orderCreatedNoMpHtml(orderId, total) {
    return `
      <div class="form-page">
        <h1>Pedido creado</h1>
        <p class="lead">Tu número de pedido es <strong>${esc(orderId)}</strong> — total ${money(total)}.</p>
        <div class="notice">
          El cobro online con Mercado Pago todavía no está activado en esta tienda.
          Guardá tu número de pedido: el admin va a configurar Mercado Pago y podrás pagar,
          o te van a contactar para coordinar el pago.
        </div>
        <a href="#/seguimiento/${orderId}" class="btn btn-solid-dark">Ver estado del pedido</a>
      </div>
    `;
  }

  function handleMpReturn() {
    const params = new URLSearchParams(location.search);
    const order = params.get("order");
    const status = params.get("status");
    if (order && status) {
      const msgs = {
        success: "¡Pago aprobado! Ya estamos preparando tu pedido.",
        pending: "Tu pago está pendiente de confirmación.",
        failure: "El pago no se pudo procesar. Podés intentar de nuevo.",
      };
      showToast(msgs[status] || "");
      history.replaceState(null, "", location.pathname + location.hash);
      if (status === "success" || status === "pending") {
        location.hash = `#/seguimiento/${order}`;
      }
    }
  }

  // ---------------------------------------------------------
  // Vista: SEGUIMIENTO
  // ---------------------------------------------------------
  function renderTracking(orderId) {
    app.innerHTML = `
      <div class="form-page">
        <h1>Seguimiento de pedido</h1>
        <p class="lead">Ingresá tu número de pedido para ver el estado.</p>
        <form id="trackForm" style="display:flex; gap:10px;">
          <input type="text" id="trackInput" placeholder="Ej: A1B2C3D4" style="flex:1; padding:13px 14px; border:1px solid var(--line); border-radius:2px;" value="${orderId ? esc(orderId) : ""}" />
          <button class="btn btn-solid-dark" type="submit">BUSCAR</button>
        </form>
        <div id="trackResult"></div>
      </div>
    `;
    scrollAppTop();
    document.getElementById("trackForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const id = document.getElementById("trackInput").value.trim();
      if (id) lookupOrder(id);
    });
    if (orderId) lookupOrder(orderId);
  }

  async function lookupOrder(id) {
    const box = document.getElementById("trackResult");
    box.innerHTML = `<p style="margin-top:20px;color:#6b6459">Buscando...</p>`;
    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(id)}`);
      if (!res.ok) {
        box.innerHTML = `<div class="notice" style="margin-top:20px">No encontramos ese pedido. Revisá el número e intentá de nuevo.</div>`;
        return;
      }
      const order = await res.json();
      const currentIdx = STATUS_STEPS.indexOf(order.status);
      box.innerHTML = `
        <div class="tracker">
          <p style="font-size:13px;color:#6b6459;margin-bottom:20px">Pedido <strong>${esc(order.id)}</strong> · ${order.itemsCount} producto(s) · ${money(order.total)}</p>
          <div class="tracker-steps">
            ${STATUS_STEPS.map((s, i) => `
              <div class="tstep ${i <= currentIdx ? "done" : ""}">
                <div>
                  <div class="tstep__dot"></div>
                  ${i < STATUS_STEPS.length - 1 ? '<div class="tstep__line"></div>' : ""}
                </div>
                <div>
                  <div class="tstep__label">${s}</div>
                </div>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    } catch {
      box.innerHTML = `<div class="notice" style="margin-top:20px">Error al buscar el pedido. Intentá de nuevo.</div>`;
    }
  }

  // ---------------------------------------------------------
  // Vista: CONTACTO
  // ---------------------------------------------------------
  function renderContact() {
    const { site } = state.store;
    app.innerHTML = `
      <section class="section">
        <div class="container">
          <div class="section-head"><h2 class="section-title">Contacto</h2></div>
          ${contactCardsHtml(site)}
        </div>
      </section>
    `;
    scrollAppTop();
  }

  function contactCardsHtml(site) {
    const cards = [];
    if (site.contact.whatsapp) {
      cards.push(contactCard("WhatsApp", site.contact.whatsapp, `https://wa.me/${site.contact.whatsapp}`));
    }
    if (site.contact.instagram) {
      cards.push(contactCard("Instagram", "@" + site.contact.instagram, `https://instagram.com/${site.contact.instagram}`));
    }
    if (site.contact.email) {
      cards.push(contactCard("Email", site.contact.email, `mailto:${site.contact.email}`));
    }
    return `<div class="contact-grid">${cards.join("")}</div>`;
  }
  function contactCard(label, value, href) {
    return `
      <a class="contact-card" href="${href}" target="_blank" rel="noopener">
        <div><p class="contact-card__label">${label}</p><p class="contact-card__value">${esc(value)}</p></div>
        <span>→</span>
      </a>
    `;
  }

  // ---------------------------------------------------------
  // Legales
  // ---------------------------------------------------------
  function renderLegal(which) {
    const title = which === "privacidad" ? "Política de privacidad" : "Términos y condiciones";
    app.innerHTML = `
      <div class="form-page">
        <h1>${title}</h1>
        <p class="lead">Este texto es un punto de partida. Reemplazalo con el contenido legal definitivo de KODO desde el panel de administración o editando el sitio.</p>
      </div>
    `;
    scrollAppTop();
  }

  // ---------------------------------------------------------
  // Utils
  // ---------------------------------------------------------
  function money(n) { return "$U " + Number(n || 0).toLocaleString("es-UY"); }
  function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  let toastTimer;
  function showToast(msg) {
    const t = document.getElementById("toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 3200);
  }
})();
